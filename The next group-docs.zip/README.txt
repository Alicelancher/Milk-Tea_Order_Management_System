Windows 10 Intel(R) Core(TM) i5-10500H CPU @ 2.50GHz 2.50 GHz
Database version:Sqlserver 2008 R2 SP2
Instance Name:TM_SQLEXPRESS
Database name:T&M

1 Deploying the database
1.1 Install Sqlserver 2008 R2 SP2 and create an instance named ‘TM_SQLEXPRESS’
1.2 Install the database management system SQL Server Management Studio 20
1.3 Use SQL Server Management Studio to execute the two sql files ‘T&M_Management_Database.sql’ and ‘Data.sql‘ in sequence

2 Installing the Application
Run the ’setup.exe‘ installation program.