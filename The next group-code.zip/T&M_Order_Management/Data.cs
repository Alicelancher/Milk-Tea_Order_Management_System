﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Milk_Tea_Order_Management
{
    internal class Data
    {
        public static string UID = "", UName = "";//登录用户的ID和姓名
    }
}
 